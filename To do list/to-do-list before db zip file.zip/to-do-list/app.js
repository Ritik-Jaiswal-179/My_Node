const express = require("express");
const bodyparser = require("body-parser");
const app = express();
const date = require(__dirname+"/date.js");

app.set('view engine', 'ejs');
app.use(bodyparser.urlencoded({ extended: true }));
app.use(express.static("public"));

const items = [];
const workItems = [];


app.get("/", (req, res) => {
    let day = date.getDay();
    res.render("list", { kindOfDay: day, newItem: items });
});

app.post("/", (req, res) => {
    console.log(req.body);
    let item = req.body.Newitem;
    
    if (req.body.btn === "Work List") {
        workItems.push(item);
        res.redirect("/work");
    }
    else {
        items.push(item);
        res.redirect("/");
    }
});

app.get("/work", (req, res) => {
    res.render("list", { 
        kindOfDay: "Work List", newItem: workItems });
});
 

app.listen(3000, () => {
    console.log("Server started at port 3000");
});
